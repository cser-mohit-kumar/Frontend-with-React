import React from 'react'
import { store } from './redux/store';
import { Provider } from 'react-redux';
import Component1 from './Components/Component1';
import Component2 from './Components/Component2';
// import { Provider } from 'redux';
const App = () => {
  return (
    <div>
      <Provider store={store}>
    <Component2/>
    <Component1/>
      </Provider>
    </div>
  )
}
export default App