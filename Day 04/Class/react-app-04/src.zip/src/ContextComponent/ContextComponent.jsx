import React, { createContext } from 'react'

export let contextAPI=createContext();

const ContextComponent = (props) => {
    console.log(props);
    
    // console.log(contextAPI);
    let {Provider}=contextAPI;
    
  return (
    <div>
        <Provider value={{name:'JECRC'}}>
            {props.children}
        </Provider>
    </div>
  )
}

export default ContextComponent