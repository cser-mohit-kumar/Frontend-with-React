import React from 'react'
import { contextAPI } from './ContextComponent'
import { useContext } from 'react'

const ContextChild = () => {
    let {Consumer}=contextAPI
    let data=useContext(contextAPI)
  return (
    <div>
        {
            data.name
        }
        {/* <Consumer>
            {(value)=>{
                console.log(value);
                
            }}
        </Consumer> */}
    </div>
  )
}

export default ContextChild