import React from 'react'
import Child from './Child'

const Parent = (props) => {
  return (
    <div>
        <Child value={props}></Child>
    </div>
  )
}

export default Parent